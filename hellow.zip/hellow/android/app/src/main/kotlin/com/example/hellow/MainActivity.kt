package com.example.hellow

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
